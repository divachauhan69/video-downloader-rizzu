import { Link, useLocation } from "wouter";
import { Home, Folder, PlayCircle, Shield, Settings } from "lucide-react";

export function BottomNavigation() {
  const [location] = useLocation();
  
  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/files", icon: Folder, label: "Files" },
    { path: "/player", icon: PlayCircle, label: "Player" },
    { path: "/vault", icon: Shield, label: "Vault" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  return (
    <nav className="absolute bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
      <div className="flex items-center justify-around py-2">
        {navItems.map(({ path, icon: Icon, label }) => (
          <Link key={path} href={path}>
            <button 
              className={`flex flex-col items-center p-2 transition-colors ${
                location === path 
                  ? "text-blue-600" 
                  : "text-gray-400 hover:text-blue-600"
              }`}
            >
              <Icon className="text-lg" />
              <span className="text-xs mt-1">{label}</span>
            </button>
          </Link>
        ))}
      </div>
    </nav>
  );
}
