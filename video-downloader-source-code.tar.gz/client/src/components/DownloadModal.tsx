import { useState } from "react";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

interface FormatOption {
  id: string;
  quality: string;
  format: string;
  size: string;
  isPremium?: boolean;
}

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDownload: (format: FormatOption) => void;
  formats?: FormatOption[];
}

const defaultFormats: FormatOption[] = [
  { id: "4k", quality: "4K Ultra HD", format: "MP4", size: "2.1 GB", isPremium: true },
  { id: "1080p", quality: "1080p Full HD", format: "MP4", size: "845 MB" },
  { id: "720p", quality: "720p HD", format: "MP4", size: "425 MB" },
  { id: "audio", quality: "Audio Only", format: "MP3", size: "12.5 MB" },
];

export function DownloadModal({ 
  isOpen, 
  onClose, 
  onDownload, 
  formats = defaultFormats 
}: DownloadModalProps) {
  const [selectedFormat, setSelectedFormat] = useState("1080p");

  if (!isOpen) return null;

  const handleDownload = () => {
    const format = formats.find(f => f.id === selectedFormat);
    if (format) {
      onDownload(format);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-t-2xl w-full max-w-sm transform transition-transform duration-300">
        <div className="p-4">
          <div className="w-8 h-1 bg-gray-300 rounded-full mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-4">Download Options</h3>
          
          <RadioGroup value={selectedFormat} onValueChange={setSelectedFormat}>
            <div className="space-y-3">
              {formats.map((format) => (
                <div 
                  key={format.id}
                  className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
                >
                  <div className="flex items-center space-x-3">
                    <RadioGroupItem 
                      value={format.id} 
                      id={format.id}
                      disabled={format.isPremium}
                    />
                    <Label htmlFor={format.id} className="flex-1">
                      <div>
                        <span className="font-medium">{format.quality}</span>
                        <p className="text-sm text-gray-500">
                          {format.format} • {format.size}
                        </p>
                      </div>
                    </Label>
                  </div>
                  {format.isPremium && (
                    <Badge variant="secondary" className="bg-orange-500 text-white">
                      PRO
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </RadioGroup>
          
          <div className="flex space-x-3 mt-6">
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button 
              className="flex-1 bg-blue-600 hover:bg-blue-700" 
              onClick={handleDownload}
            >
              Download
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
