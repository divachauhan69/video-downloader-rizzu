import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

interface MobileContainerProps {
  children: ReactNode;
  className?: string;
}

export function MobileContainer({ children, className }: MobileContainerProps) {
  return (
    <div className={cn(
      "max-w-sm mx-auto bg-white dark:bg-gray-900 shadow-2xl min-h-screen relative overflow-hidden",
      className
    )}>
      {/* Status Bar */}
      <div className="flex justify-between items-center px-4 py-2 bg-black text-white text-xs">
        <span>9:41 AM</span>
        <div className="flex items-center space-x-1">
          <i className="fas fa-signal text-xs"></i>
          <i className="fas fa-wifi text-xs"></i>
          <span>100%</span>
          <i className="fas fa-battery-full text-xs"></i>
        </div>
      </div>
      
      {children}
    </div>
  );
}
