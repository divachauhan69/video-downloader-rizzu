import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Play, Trash2, Pause, X } from "lucide-react";
import type { Download } from "@shared/schema";

interface DownloadItemProps {
  download: Download;
  onPlay?: () => void;
  onDelete?: () => void;
  onPause?: () => void;
  onCancel?: () => void;
}

export function DownloadItem({ download, onPlay, onDelete, onPause, onCancel }: DownloadItemProps) {
  const getStatusColor = () => {
    switch (download.status) {
      case "completed": return "bg-green-500";
      case "downloading": return "bg-blue-500";
      case "failed": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const getActionButtons = () => {
    if (download.status === "downloading") {
      return (
        <div className="flex items-center space-x-2">
          <Button 
            size="sm" 
            variant="ghost" 
            className="p-2 text-orange-500 hover:text-orange-600"
            onClick={onPause}
          >
            <Pause className="h-4 w-4" />
          </Button>
          <Button 
            size="sm" 
            variant="ghost" 
            className="p-2 text-gray-400 hover:text-red-500"
            onClick={onCancel}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      );
    }

    return (
      <div className="flex items-center space-x-2">
        {download.status === "completed" && (
          <Button 
            size="sm" 
            variant="ghost" 
            className="p-2 text-gray-400 hover:text-blue-500"
            onClick={onPlay}
          >
            <Play className="h-4 w-4" />
          </Button>
        )}
        <Button 
          size="sm" 
          variant="ghost" 
          className="p-2 text-gray-400 hover:text-red-500"
          onClick={onDelete}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    );
  };

  return (
    <div className="p-4 flex items-center space-x-3">
      <img 
        src={download.thumbnail || "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=100&h=75"} 
        alt={download.title}
        className="w-16 h-12 rounded-lg object-cover" 
      />
      <div className="flex-1 min-w-0">
        <p className="font-medium truncate">{download.title}</p>
        <div className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400">
          <span>{download.size}</span>
          <span>•</span>
          <span>{download.duration}</span>
        </div>
        
        {download.status === "downloading" && (
          <>
            <Progress value={download.progress} className="mt-2 h-1.5" />
            <span className="text-xs text-blue-500 mt-1">
              Downloading... {download.progress}%
            </span>
          </>
        )}
        
        {download.status === "completed" && (
          <div className="mt-2 bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
            <div className={`${getStatusColor()} h-1.5 rounded-full w-full`} />
          </div>
        )}
      </div>
      
      {getActionButtons()}
    </div>
  );
}
