import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Play, Pause, Download as DownloadIcon, Clock, Eye, Heart, Share, Volume2 } from "lucide-react";
import type { VideoInfo } from "@shared/schema";

interface VideoPreviewProps {
  videoInfo: VideoInfo;
  onDownload: () => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function VideoPreview({ videoInfo, onDownload, onCancel, isLoading = false }: VideoPreviewProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const videoRef = useRef<HTMLVideoElement>(null);

  const formatViews = (views: number) => {
    if (views >= 1000000) {
      return `${(views / 1000000).toFixed(1)}M views`;
    } else if (views >= 1000) {
      return `${(views / 1000).toFixed(1)}K views`;
    }
    return `${views} views`;
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const getVideoSource = (url: string) => {
    // For demo purposes, return a sample video URL
    // In real implementation, this would extract the actual video stream URL
    return "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";
  };

  // Mock video stats for demo
  const videoStats = {
    views: 2547832,
    likes: 45632,
    uploadDate: "2 days ago"
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 backdrop-blur-sm animate-fade-in">
      <Card className="w-full max-w-sm bg-white dark:bg-gray-800 rounded-2xl overflow-hidden transform transition-all duration-300 scale-100 animate-slide-up shadow-2xl">
        {/* Video Player */}
        <div 
          className="relative"
          onMouseEnter={() => setShowControls(true)}
          onMouseLeave={() => setShowControls(false)}
        >
          <video 
            ref={videoRef}
            className="w-full h-48 object-cover bg-black"
            poster={videoInfo.thumbnail || "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=225"}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onClick={togglePlay}
            controls={false}
          >
            <source src={getVideoSource(videoInfo.url)} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          
          {/* Video Controls Overlay */}
          <div className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${showControls ? 'opacity-100' : 'opacity-0'}`}>
            <Button
              size="lg"
              className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm hover:bg-white/30"
              onClick={togglePlay}
            >
              {isPlaying ? (
                <Pause className="text-white text-xl" />
              ) : (
                <Play className="text-white text-xl ml-1" />
              )}
            </Button>
          </div>

          {/* Video Controls Bar */}
          {showControls && (
            <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent">
              <div className="flex items-center space-x-3">
                <Button
                  size="sm"
                  variant="ghost"
                  className="p-1 text-white hover:bg-white/20"
                  onClick={togglePlay}
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="p-1 text-white hover:bg-white/20"
                >
                  <Volume2 className="h-4 w-4" />
                </Button>
                <div className="flex-1 text-white text-xs">
                  Preview • {videoInfo.duration}
                </div>
              </div>
            </div>
          )}
          
          {/* Duration Badge */}
          {videoInfo.duration && (
            <Badge className="absolute bottom-2 right-2 bg-black/70 text-white">
              <Clock className="mr-1 h-3 w-3" />
              {videoInfo.duration}
            </Badge>
          )}

          {/* Platform Badge */}
          <Badge className="absolute top-2 left-2 bg-red-600 text-white">
            {videoInfo.platform}
          </Badge>
        </div>

        <CardContent className="p-4 space-y-4">
          {/* Video Title */}
          <div>
            <h3 className="font-semibold text-lg truncate-2 mb-2">
              {videoInfo.title}
            </h3>
            
            {/* Video Stats */}
            <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 space-x-3">
              <span className="flex items-center">
                <Eye className="mr-1 h-3 w-3" />
                {formatViews(videoStats.views)}
              </span>
              <span>•</span>
              <span>{videoStats.uploadDate}</span>
            </div>
          </div>

          {/* Available Formats Preview */}
          <div>
            <p className="text-sm font-medium mb-2">Available Formats:</p>
            <div className="flex flex-wrap gap-2">
              {videoInfo.availableFormats?.slice(0, 3).map((format, index) => {
                const quality = format.split(' ')[0];
                const isPremium = quality === '4K';
                return (
                  <Badge 
                    key={index} 
                    variant={isPremium ? "default" : "outline"} 
                    className={`text-xs ${isPremium ? 'bg-orange-500 text-white' : ''}`}
                  >
                    {quality}
                    {isPremium && <span className="ml-1">PRO</span>}
                  </Badge>
                );
              }) || (
                <Badge variant="outline" className="text-xs">
                  Multiple formats available
                </Badge>
              )}
              {videoInfo.availableFormats && videoInfo.availableFormats.length > 3 && (
                <Badge variant="secondary" className="text-xs">
                  +{videoInfo.availableFormats.length - 3} more
                </Badge>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-3">
              <Button
                size="sm"
                variant="ghost"
                className={`p-2 ${isLiked ? 'text-red-500' : 'text-gray-400'}`}
                onClick={() => setIsLiked(!isLiked)}
              >
                <Heart className={`h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
              </Button>
              <Button size="sm" variant="ghost" className="p-2 text-gray-400">
                <Share className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={onCancel}
                disabled={isLoading}
              >
                Cancel
              </Button>
              <Button 
                size="sm"
                className="bg-blue-600 hover:bg-blue-700"
                onClick={onDownload}
                disabled={isLoading}
              >
                <DownloadIcon className="mr-2 h-4 w-4" />
                {isLoading ? "Processing..." : "Download"}
              </Button>
            </div>
          </div>

          {/* Video URL Info */}
          <div className="bg-blue-50 dark:bg-blue-900/30 rounded-lg p-3 border border-blue-200 dark:border-blue-700">
            <div className="text-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-blue-600 dark:text-blue-300 font-medium">Source URL:</span>
                <Badge variant="outline" className="text-xs">{videoInfo.platform}</Badge>
              </div>
              <p className="text-gray-600 dark:text-gray-300 text-xs truncate mb-2">
                {videoInfo.url}
              </p>
              <div className="bg-yellow-100 dark:bg-yellow-900/30 border border-yellow-300 dark:border-yellow-700 rounded px-2 py-1">
                <p className="text-yellow-700 dark:text-yellow-300 text-xs">
                  ⚠️ Demo Mode: Video info generated for preview purposes
                </p>
              </div>
            </div>
          </div>

          {/* Quality/Size Info */}
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-600 dark:text-gray-300">Recommended:</span>
              <span className="font-medium">1080p HD • ~845 MB</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}