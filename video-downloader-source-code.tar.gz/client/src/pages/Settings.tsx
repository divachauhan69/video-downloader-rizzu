import { MobileContainer } from "@/components/ui/mobile-container";
import { BottomNavigation } from "@/components/BottomNavigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useTheme } from "@/contexts/ThemeContext";
import { Settings as SettingsIcon, User, Download, Shield, Bell, HelpCircle, Star, Crown } from "lucide-react";

export default function Settings() {
  const { theme, toggleTheme } = useTheme();

  return (
    <MobileContainer>
      {/* Header */}
      <header className="bg-blue-600 dark:bg-gray-800 text-white px-4 py-4 shadow-lg">
        <div className="flex items-center space-x-3">
          <SettingsIcon className="text-xl" />
          <h1 className="text-lg font-bold">Settings</h1>
        </div>
      </header>

      <main className="pb-20 p-4 space-y-4">
        {/* Profile Section */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                <User className="text-2xl text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">Pro User</h3>
                <p className="text-sm text-gray-500">premium@example.com</p>
                <Badge className="mt-1 bg-orange-500 text-white">
                  <Crown className="mr-1 h-3 w-3" />
                  Premium
                </Badge>
              </div>
              <Button variant="outline" size="sm">
                Edit
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Premium Section */}
        <Card className="border-orange-200 bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-orange-800 dark:text-orange-200">
                  Premium Features
                </h3>
                <p className="text-sm text-orange-600 dark:text-orange-300">
                  Expires in 25 days
                </p>
              </div>
              <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                Manage
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Download Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Download className="mr-2 h-4 w-4" />
              Download Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Default Video Quality</span>
              <select className="bg-gray-100 dark:bg-gray-700 rounded px-3 py-1">
                <option value="720p">720p HD</option>
                <option value="1080p" selected>1080p Full HD</option>
                <option value="4k">4K Ultra HD</option>
              </select>
            </div>
            <div className="flex justify-between items-center">
              <span>Download Location</span>
              <Button variant="outline" size="sm">
                Change
              </Button>
            </div>
            <div className="flex justify-between items-center">
              <span>Auto-download Subtitles</span>
              <Switch defaultChecked />
            </div>
            <div className="flex justify-between items-center">
              <span>Parallel Downloads</span>
              <select className="bg-gray-100 dark:bg-gray-700 rounded px-3 py-1">
                <option value="1">1</option>
                <option value="2" selected>2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </div>
          </CardContent>
        </Card>

        {/* Privacy & Security */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="mr-2 h-4 w-4" />
              Privacy & Security
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Private Vault</span>
              <Button variant="outline" size="sm">
                Configure
              </Button>
            </div>
            <div className="flex justify-between items-center">
              <span>Clear Download History</span>
              <Button variant="outline" size="sm">
                Clear
              </Button>
            </div>
            <div className="flex justify-between items-center">
              <span>Incognito Mode</span>
              <Switch />
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Bell className="mr-2 h-4 w-4" />
              Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Download Complete</span>
              <Switch defaultChecked />
            </div>
            <div className="flex justify-between items-center">
              <span>Download Progress</span>
              <Switch defaultChecked />
            </div>
            <div className="flex justify-between items-center">
              <span>App Updates</span>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        {/* Appearance */}
        <Card>
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Dark Mode</span>
              <Switch 
                checked={theme === "dark"} 
                onCheckedChange={toggleTheme}
              />
            </div>
            <div className="flex justify-between items-center">
              <span>Language</span>
              <select className="bg-gray-100 dark:bg-gray-700 rounded px-3 py-1">
                <option value="en" selected>English</option>
                <option value="es">Español</option>
                <option value="fr">Français</option>
                <option value="de">Deutsch</option>
              </select>
            </div>
          </CardContent>
        </Card>

        {/* Support */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <HelpCircle className="mr-2 h-4 w-4" />
              Support
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="ghost" className="w-full justify-start">
              <i className="fas fa-question-circle mr-3" />
              Help Center
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <i className="fas fa-envelope mr-3" />
              Contact Support
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Star className="mr-3 h-4 w-4" />
              Rate App
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <i className="fas fa-share mr-3" />
              Share App
            </Button>
          </CardContent>
        </Card>

        {/* About */}
        <Card>
          <CardContent className="p-4 text-center text-sm text-gray-500">
            <p>Video Downloader v2.1.0</p>
            <p>© 2024 All rights reserved</p>
          </CardContent>
        </Card>
      </main>

      <BottomNavigation />
    </MobileContainer>
  );
}
