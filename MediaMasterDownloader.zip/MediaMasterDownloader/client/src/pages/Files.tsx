import { useQuery, useMutation } from "@tanstack/react-query";
import { MobileContainer } from "@/components/ui/mobile-container";
import { BottomNavigation } from "@/components/BottomNavigation";
import { DownloadItem } from "@/components/DownloadItem";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Folder, Filter, Search } from "lucide-react";
import type { Download } from "@shared/schema";

export default function Files() {
  const { toast } = useToast();

  const { data: downloads = [], isLoading } = useQuery({
    queryKey: ["/api/downloads"],
  });

  const deleteDownloadMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/downloads/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/downloads"] });
      toast({
        title: "Download Deleted",
        description: "The download has been removed",
      });
    },
  });

  const getStorageUsed = () => {
    if (!downloads.length) return "0 MB";
    // Mock calculation
    return "1.2 GB";
  };

  const getDownloadsByStatus = (status: string) => {
    return downloads.filter((d: Download) => d.status === status);
  };

  return (
    <MobileContainer>
      {/* Header */}
      <header className="bg-blue-600 dark:bg-gray-800 text-white px-4 py-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Folder className="text-xl" />
            <h1 className="text-lg font-bold">File Manager</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Button size="sm" variant="ghost" className="text-white">
              <Search className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" className="text-white">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="pb-20 p-4 space-y-4">
        {/* Storage Info */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-semibold">Storage Used</h3>
                <p className="text-2xl font-bold text-blue-600">{getStorageUsed()}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">Total Downloads</p>
                <p className="text-lg font-semibold">{downloads.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Status Overview */}
        <div className="grid grid-cols-3 gap-2">
          <Card>
            <CardContent className="p-3 text-center">
              <p className="text-lg font-bold text-green-600">
                {getDownloadsByStatus("completed").length}
              </p>
              <p className="text-xs text-gray-500">Completed</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <p className="text-lg font-bold text-blue-600">
                {getDownloadsByStatus("downloading").length}
              </p>
              <p className="text-xs text-gray-500">Active</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <p className="text-lg font-bold text-red-600">
                {getDownloadsByStatus("failed").length}
              </p>
              <p className="text-xs text-gray-500">Failed</p>
            </CardContent>
          </Card>
        </div>

        {/* Downloads List */}
        <Card>
          <CardHeader>
            <CardTitle>All Downloads</CardTitle>
          </CardHeader>
          
          {isLoading ? (
            <CardContent>
              <div className="text-center py-8 text-gray-500">Loading downloads...</div>
            </CardContent>
          ) : downloads.length === 0 ? (
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <Folder className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No downloads yet</p>
                <p className="text-sm">Start downloading videos to see them here</p>
              </div>
            </CardContent>
          ) : (
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {downloads.map((download: Download) => (
                <DownloadItem
                  key={download.id}
                  download={download}
                  onDelete={() => deleteDownloadMutation.mutate(download.id)}
                />
              ))}
            </div>
          )}
        </Card>
      </main>

      <BottomNavigation />
    </MobileContainer>
  );
}
