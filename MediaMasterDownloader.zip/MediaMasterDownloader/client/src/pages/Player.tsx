import { useState } from "react";
import { MobileContainer } from "@/components/ui/mobile-container";
import { BottomNavigation } from "@/components/BottomNavigation";
import { VideoPlayer } from "@/components/VideoPlayer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlayCircle, List, Shuffle, Repeat } from "lucide-react";

export default function Player() {
  const [currentVideo, setCurrentVideo] = useState({
    title: "Beautiful Sunrise Timelapse",
    thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=450",
    duration: 225,
    currentTime: 83,
  });

  const playlist = [
    {
      id: 1,
      title: "Beautiful Sunrise Timelapse",
      thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=100&h=75",
      duration: "3:45",
    },
    {
      id: 2,
      title: "Ocean Waves Relaxation",
      thumbnail: "https://images.unsplash.com/photo-1439066615861-d1af74d74000?w=100&h=75",
      duration: "10:30",
    },
    {
      id: 3,
      title: "Mountain Adventure",
      thumbnail: "https://images.unsplash.com/photo-1464822759844-d150baec013c?w=100&h=75",
      duration: "7:22",
    },
  ];

  return (
    <MobileContainer>
      {/* Header */}
      <header className="bg-blue-600 dark:bg-gray-800 text-white px-4 py-4 shadow-lg">
        <div className="flex items-center space-x-3">
          <PlayCircle className="text-xl" />
          <h1 className="text-lg font-bold">Video Player</h1>
        </div>
      </header>

      <main className="pb-20 space-y-4">
        {/* Video Player */}
        <section className="p-4">
          <VideoPlayer 
            thumbnail={currentVideo.thumbnail}
            title={currentVideo.title}
            currentTime={currentVideo.currentTime}
            duration={currentVideo.duration}
          />
          
          {/* Video Info */}
          <div className="mt-4">
            <h2 className="text-lg font-semibold">{currentVideo.title}</h2>
            <p className="text-sm text-gray-500">Downloaded • MP4 • 1080p</p>
          </div>

          {/* Player Controls */}
          <div className="flex items-center justify-center space-x-6 mt-4">
            <Button size="sm" variant="ghost">
              <Shuffle className="h-5 w-5" />
            </Button>
            <Button size="sm" variant="ghost">
              <i className="fas fa-step-backward text-lg" />
            </Button>
            <Button size="lg" className="w-12 h-12 rounded-full bg-blue-600 hover:bg-blue-700">
              <i className="fas fa-play text-lg ml-1" />
            </Button>
            <Button size="sm" variant="ghost">
              <i className="fas fa-step-forward text-lg" />
            </Button>
            <Button size="sm" variant="ghost">
              <Repeat className="h-5 w-5" />
            </Button>
          </div>
        </section>

        {/* Playlist */}
        <section className="px-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <List className="mr-2" />
                Up Next
              </CardTitle>
            </CardHeader>
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {playlist.map((video) => (
                <div 
                  key={video.id}
                  className="p-4 flex items-center space-x-3 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                  onClick={() => setCurrentVideo({
                    title: video.title,
                    thumbnail: video.thumbnail,
                    duration: 225,
                    currentTime: 0,
                  })}
                >
                  <img 
                    src={video.thumbnail} 
                    alt={video.title}
                    className="w-16 h-12 rounded-lg object-cover" 
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{video.title}</p>
                    <p className="text-sm text-gray-500">{video.duration}</p>
                  </div>
                  <Button size="sm" variant="ghost">
                    <PlayCircle className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </Card>
        </section>

        {/* Playback Settings */}
        <section className="px-4">
          <Card>
            <CardHeader>
              <CardTitle>Playback Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Playback Speed</span>
                <select className="bg-gray-100 dark:bg-gray-700 rounded px-2 py-1">
                  <option value="0.5">0.5x</option>
                  <option value="1" selected>1x</option>
                  <option value="1.25">1.25x</option>
                  <option value="1.5">1.5x</option>
                  <option value="2">2x</option>
                </select>
              </div>
              <div className="flex justify-between items-center">
                <span>Auto-play Next</span>
                <input type="checkbox" defaultChecked className="toggle" />
              </div>
              <div className="flex justify-between items-center">
                <span>Picture-in-Picture</span>
                <Button size="sm" variant="outline">
                  Enable PiP
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      <BottomNavigation />
    </MobileContainer>
  );
}
