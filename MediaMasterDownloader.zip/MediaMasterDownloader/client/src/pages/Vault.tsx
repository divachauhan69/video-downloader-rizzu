import { useState } from "react";
import { MobileContainer } from "@/components/ui/mobile-container";
import { BottomNavigation } from "@/components/BottomNavigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Shield, Lock, Fingerprint, Eye, EyeOff } from "lucide-react";

export default function Vault() {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);

  const vaultItems = [
    {
      id: 1,
      title: "Private Video 1",
      thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=100&h=75",
      duration: "5:30",
      size: "25.4 MB",
    },
    {
      id: 2,
      title: "Personal Content",
      thumbnail: "https://images.unsplash.com/photo-1439066615861-d1af74d74000?w=100&h=75",
      duration: "3:15",
      size: "18.2 MB",
    },
  ];

  const handleUnlock = () => {
    if (pin === "1234") {
      setIsUnlocked(true);
      setPin("");
    }
  };

  const handleLock = () => {
    setIsUnlocked(false);
    setPin("");
  };

  if (!isUnlocked) {
    return (
      <MobileContainer>
        {/* Header */}
        <header className="bg-blue-600 dark:bg-gray-800 text-white px-4 py-4 shadow-lg">
          <div className="flex items-center space-x-3">
            <Shield className="text-xl" />
            <h1 className="text-lg font-bold">Private Vault</h1>
          </div>
        </header>

        <main className="pb-20 p-4 flex items-center justify-center min-h-[60vh]">
          <Card className="w-full max-w-sm">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="text-2xl text-gray-600" />
              </div>
              <CardTitle>Unlock Private Vault</CardTitle>
              <p className="text-sm text-gray-500">
                Enter your PIN or use biometric authentication
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <Input
                  type={showPin ? "text" : "password"}
                  placeholder="Enter PIN"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  maxLength={4}
                  className="text-center text-lg tracking-widest"
                />
                <Button
                  size="sm"
                  variant="ghost"
                  className="absolute right-2 top-2 bottom-2"
                  onClick={() => setShowPin(!showPin)}
                >
                  {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>

              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={handleUnlock}
                disabled={pin.length !== 4}
              >
                <Lock className="mr-2 h-4 w-4" />
                Unlock with PIN
              </Button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">or</span>
                </div>
              </div>

              <Button variant="outline" className="w-full">
                <Fingerprint className="mr-2 h-4 w-4" />
                Use Fingerprint
              </Button>

              <p className="text-xs text-center text-gray-500">
                Demo PIN: 1234
              </p>
            </CardContent>
          </Card>
        </main>

        <BottomNavigation />
      </MobileContainer>
    );
  }

  return (
    <MobileContainer>
      {/* Header */}
      <header className="bg-blue-600 dark:bg-gray-800 text-white px-4 py-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Shield className="text-xl" />
            <h1 className="text-lg font-bold">Private Vault</h1>
          </div>
          <Button size="sm" variant="ghost" className="text-white" onClick={handleLock}>
            <Lock className="h-4 w-4" />
          </Button>
        </div>
      </header>

      <main className="pb-20 p-4 space-y-4">
        {/* Vault Info */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold flex items-center">
                  <Shield className="mr-2 h-4 w-4 text-green-600" />
                  Vault Unlocked
                </h3>
                <p className="text-sm text-gray-500">
                  {vaultItems.length} private items stored securely
                </p>
              </div>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                Secure
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Vault Contents */}
        <Card>
          <CardHeader>
            <CardTitle>Private Downloads</CardTitle>
          </CardHeader>
          
          {vaultItems.length === 0 ? (
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <Shield className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No private content yet</p>
                <p className="text-sm">Move downloads here for privacy</p>
              </div>
            </CardContent>
          ) : (
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {vaultItems.map((item) => (
                <div key={item.id} className="p-4 flex items-center space-x-3">
                  <img 
                    src={item.thumbnail} 
                    alt={item.title}
                    className="w-16 h-12 rounded-lg object-cover" 
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{item.title}</p>
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <span>{item.size}</span>
                      <span>•</span>
                      <span>{item.duration}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button size="sm" variant="ghost">
                      <i className="fas fa-play text-gray-400" />
                    </Button>
                    <Button size="sm" variant="ghost">
                      <i className="fas fa-share text-gray-400" />
                    </Button>
                    <Button size="sm" variant="ghost">
                      <i className="fas fa-trash text-gray-400" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Security Settings */}
        <Card>
          <CardHeader>
            <CardTitle>Security Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Auto-lock Timer</span>
              <select className="bg-gray-100 dark:bg-gray-700 rounded px-2 py-1">
                <option value="1">1 minute</option>
                <option value="5" selected>5 minutes</option>
                <option value="15">15 minutes</option>
                <option value="30">30 minutes</option>
              </select>
            </div>
            <div className="flex justify-between items-center">
              <span>Fingerprint Unlock</span>
              <input type="checkbox" defaultChecked className="toggle" />
            </div>
            <div className="flex justify-between items-center">
              <span>Hide from Recent Apps</span>
              <input type="checkbox" defaultChecked className="toggle" />
            </div>
            <Button variant="outline" className="w-full">
              Change PIN
            </Button>
          </CardContent>
        </Card>
      </main>

      <BottomNavigation />
    </MobileContainer>
  );
}
