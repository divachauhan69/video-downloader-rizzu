import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MobileContainer } from "@/components/ui/mobile-container";
import { BottomNavigation } from "@/components/BottomNavigation";
import { DownloadModal } from "@/components/DownloadModal";
import { VideoPreview } from "@/components/VideoPreview";
import { DownloadItem } from "@/components/DownloadItem";
import { PlatformBadges } from "@/components/PlatformBadges";
import { VideoPlayer } from "@/components/VideoPlayer";
import { useTheme } from "@/contexts/ThemeContext";
import { useDownload } from "@/contexts/DownloadContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Download, Globe, Save, Search, Moon, Sun, Plus } from "lucide-react";
import type { Download as DownloadType, VideoInfo } from "@shared/schema";

export default function Home() {
  const [url, setUrl] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showPlayer, setShowPlayer] = useState(false);
  const [currentVideoInfo, setCurrentVideoInfo] = useState<VideoInfo | null>(null);
  const { theme, toggleTheme } = useTheme();
  const { addDownload } = useDownload();
  const { toast } = useToast();

  // Fetch downloads
  const { data: downloads = [], isLoading } = useQuery({
    queryKey: ["/api/downloads"],
  });

  // Fetch video info mutation
  const fetchVideoInfoMutation = useMutation({
    mutationFn: async (videoUrl: string) => {
      const response = await apiRequest("POST", "/api/video-info", { url: videoUrl });
      return response.json();
    },
    onSuccess: (videoInfo: VideoInfo) => {
      setCurrentVideoInfo(videoInfo);
      setShowPreview(true);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to fetch video information",
        variant: "destructive",
      });
    },
  });

  // Create download mutation
  const createDownloadMutation = useMutation({
    mutationFn: async (downloadData: any) => {
      const response = await apiRequest("POST", "/api/downloads", downloadData);
      return response.json();
    },
    onSuccess: (download) => {
      addDownload(download);
      queryClient.invalidateQueries({ queryKey: ["/api/downloads"] });
      setShowPreview(false);
      setShowModal(false);
      setCurrentVideoInfo(null);
      setUrl("");
      toast({
        title: "Download Started",
        description: `${download.title} is now downloading...`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start download",
        variant: "destructive",
      });
    },
  });

  // Delete download mutation
  const deleteDownloadMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/downloads/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/downloads"] });
      toast({
        title: "Download Deleted",
        description: "The download has been removed",
      });
    },
  });

  const handleSearch = () => {
    if (url.trim()) {
      fetchVideoInfoMutation.mutate(url.trim());
    }
  };

  const handlePreviewDownload = () => {
    setShowPreview(false);
    setShowModal(true);
  };

  const handleDownload = (format: any) => {
    if (!currentVideoInfo) return;
    
    const downloadData = {
      title: currentVideoInfo.title,
      url: currentVideoInfo.url,
      thumbnail: currentVideoInfo.thumbnail,
      duration: currentVideoInfo.duration,
      size: format.size,
      format: format.format,
      quality: format.quality,
      platform: currentVideoInfo.platform,
      status: "pending",
      progress: 0,
    };

    createDownloadMutation.mutate(downloadData);
  };

  return (
    <MobileContainer>
      {/* App Header */}
      <header className="bg-blue-600 dark:bg-gray-800 text-white px-4 py-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <Download className="text-blue-600 text-lg" />
            </div>
            <div>
              <h1 className="text-lg font-bold">Video Downloader</h1>
              <p className="text-xs opacity-90">All-in-One Solution</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              size="sm"
              variant="ghost"
              className="p-2 rounded-full bg-white/20 hover:bg-white/30"
              onClick={toggleTheme}
            >
              {theme === "dark" ? (
                <Sun className="text-sm" />
              ) : (
                <Moon className="text-sm" />
              )}
            </Button>
            <Badge variant="secondary" className="bg-orange-500 text-white">
              PRO
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pb-20">
        {/* URL Input Section */}
        <section className="p-4">
          <Card>
            <CardContent className="p-4">
              <h2 className="text-lg font-semibold mb-3 flex items-center">
                <Download className="text-blue-600 mr-2" />
                Paste Video URL
              </h2>
              <div className="relative">
                <Input
                  type="url"
                  placeholder="Paste YouTube, TikTok, Instagram URL..."
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="pr-12"
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                />
                <Button
                  size="sm"
                  className="absolute right-2 top-2 bottom-2 bg-blue-600 hover:bg-blue-700"
                  onClick={handleSearch}
                  disabled={fetchVideoInfoMutation.isPending}
                >
                  {fetchVideoInfoMutation.isPending ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Search className="h-4 w-4" />
                  )}
                </Button>
              </div>
              
              <PlatformBadges />
            </CardContent>
          </Card>
        </section>

        {/* Quick Actions */}
        <section className="px-4 pb-4">
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              className="p-4 h-auto flex flex-col items-center space-y-2"
            >
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                <Globe className="text-blue-600 text-xl" />
              </div>
              <span className="text-sm font-medium">In-App Browser</span>
            </Button>
            
            <Button
              variant="outline"
              className="p-4 h-auto flex flex-col items-center space-y-2"
            >
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                <Save className="text-green-600 text-xl" />
              </div>
              <span className="text-sm font-medium">Status Saver</span>
            </Button>
          </div>
        </section>

        {/* Video Player (when video is playing) */}
        {showPlayer && (
          <section className="px-4 pb-4">
            <VideoPlayer />
          </section>
        )}

        {/* Recent Downloads */}
        <section className="px-4 pb-4">
          <Card>
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold flex items-center justify-between">
                <span>
                  <Download className="text-blue-600 mr-2 inline" />
                  Recent Downloads
                </span>
                <Button variant="link" size="sm" className="text-blue-600">
                  View All
                </Button>
              </h3>
            </div>
            
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {isLoading ? (
                <div className="p-4 text-center text-gray-500">Loading downloads...</div>
              ) : downloads.length === 0 ? (
                <div className="p-4 text-center text-gray-500">No downloads yet</div>
              ) : (
                downloads.slice(0, 3).map((download: DownloadType) => (
                  <DownloadItem
                    key={download.id}
                    download={download}
                    onPlay={() => setShowPlayer(true)}
                    onDelete={() => deleteDownloadMutation.mutate(download.id)}
                  />
                ))
              )}
            </div>
          </Card>
        </section>

        {/* Premium Features Banner */}
        <section className="px-4 pb-4">
          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-lg">Go Premium!</h3>
                  <p className="text-sm opacity-90">Unlock faster downloads, cloud backup & more</p>
                  <ul className="mt-2 space-y-1 text-xs">
                    <li className="flex items-center">
                      <i className="fas fa-check mr-2" />
                      No Ads
                    </li>
                    <li className="flex items-center">
                      <i className="fas fa-check mr-2" />
                      4K Downloads
                    </li>
                    <li className="flex items-center">
                      <i className="fas fa-check mr-2" />
                      Cloud Backup
                    </li>
                  </ul>
                </div>
                <Button className="bg-white text-orange-500 hover:bg-gray-100">
                  Upgrade
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      {/* Floating Action Button */}
      <Button
        className="fixed bottom-24 right-4 w-14 h-14 bg-orange-500 hover:bg-orange-600 rounded-full shadow-lg z-40"
        onClick={() => setShowModal(true)}
      >
        <Plus className="text-lg" />
      </Button>

      <BottomNavigation />
      
      {/* Video Preview Modal */}
      {showPreview && currentVideoInfo && (
        <VideoPreview
          videoInfo={currentVideoInfo}
          onDownload={handlePreviewDownload}
          onCancel={() => {
            setShowPreview(false);
            setCurrentVideoInfo(null);
          }}
          isLoading={fetchVideoInfoMutation.isPending}
        />
      )}
      
      {/* Download Format Selection Modal */}
      <DownloadModal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setCurrentVideoInfo(null);
        }}
        onDownload={handleDownload}
        formats={currentVideoInfo?.availableFormats?.map((format, index) => {
          const parts = format.split('(');
          const quality = parts[0].trim();
          const sizeInfo = parts[1]?.replace(')', '') || '~500 MB';
          return {
            id: `format-${index}`,
            quality: quality,
            format: format.includes('MP3') ? 'MP3' : 'MP4',
            size: sizeInfo,
            isPremium: format.includes('4K') || format.includes('Ultra HD')
          };
        })}
      />
    </MobileContainer>
  );
}
