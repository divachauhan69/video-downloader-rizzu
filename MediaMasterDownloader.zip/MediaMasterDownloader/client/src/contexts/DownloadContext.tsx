import { createContext, useContext, useState, type ReactNode } from "react";
import type { Download } from "@shared/schema";

interface DownloadContextType {
  activeDownloads: Download[];
  addDownload: (download: Download) => void;
  updateDownload: (id: number, updates: Partial<Download>) => void;
  removeDownload: (id: number) => void;
}

const DownloadContext = createContext<DownloadContextType | undefined>(undefined);

export function DownloadProvider({ children }: { children: ReactNode }) {
  const [activeDownloads, setActiveDownloads] = useState<Download[]>([]);

  const addDownload = (download: Download) => {
    setActiveDownloads(prev => [...prev, download]);
  };

  const updateDownload = (id: number, updates: Partial<Download>) => {
    setActiveDownloads(prev => 
      prev.map(download => 
        download.id === id ? { ...download, ...updates } : download
      )
    );
  };

  const removeDownload = (id: number) => {
    setActiveDownloads(prev => prev.filter(download => download.id !== id));
  };

  return (
    <DownloadContext.Provider value={{ 
      activeDownloads, 
      addDownload, 
      updateDownload, 
      removeDownload 
    }}>
      {children}
    </DownloadContext.Provider>
  );
}

export function useDownload() {
  const context = useContext(DownloadContext);
  if (context === undefined) {
    throw new Error("useDownload must be used within a DownloadProvider");
  }
  return context;
}
