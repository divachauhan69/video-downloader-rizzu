import { Badge } from "@/components/ui/badge";

const platforms = [
  { name: "YouTube", icon: "fab fa-youtube", color: "bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300" },
  { name: "Instagram", icon: "fab fa-instagram", color: "bg-pink-100 dark:bg-pink-900/30 text-pink-800 dark:text-pink-300" },
  { name: "Facebook", icon: "fab fa-facebook", color: "bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300" },
  { name: "TikTok", icon: "fab fa-tiktok", color: "bg-black dark:bg-gray-800 text-white" },
  { name: "WhatsApp", icon: "fab fa-whatsapp", color: "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300" },
];

export function PlatformBadges() {
  return (
    <div className="mt-4">
      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Supported Platforms:</p>
      <div className="flex flex-wrap gap-2">
        {platforms.map((platform) => (
          <span
            key={platform.name}
            className={`px-2 py-1 rounded-full text-xs ${platform.color}`}
          >
            <i className={`${platform.icon} mr-1`} />
            {platform.name}
          </span>
        ))}
      </div>
    </div>
  );
}
