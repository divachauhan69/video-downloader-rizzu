import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Play, Pause, ExternalLink } from "lucide-react";

interface VideoPlayerProps {
  src?: string;
  thumbnail?: string;
  title?: string;
  currentTime?: number;
  duration?: number;
}

export function VideoPlayer({ 
  src, 
  thumbnail, 
  title = "Video Player",
  currentTime = 83, // 1:23 in seconds
  duration = 225 // 3:45 in seconds
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = (currentTime / duration) * 100;

  return (
    <div className="bg-black rounded-xl overflow-hidden shadow-lg">
      <div 
        className="relative aspect-video cursor-pointer"
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
        onClick={togglePlay}
      >
        {src ? (
          <video 
            ref={videoRef}
            className="w-full h-full object-cover"
            poster={thumbnail}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
          >
            <source src={src} type="video/mp4" />
          </video>
        ) : (
          <img 
            src={thumbnail || "https://images.unsplash.com/photo-1439066615861-d1af74d74000?ixlib=rb-4.0.3&w=800&h=450"} 
            alt={title}
            className="w-full h-full object-cover" 
          />
        )}
        
        {/* Video Controls Overlay */}
        <div className={`absolute inset-0 bg-black/50 flex items-center justify-center transition-opacity ${showControls ? 'opacity-100' : 'opacity-0'}`}>
          <Button
            size="lg"
            className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm hover:bg-white/30"
            onClick={togglePlay}
          >
            {isPlaying ? (
              <Pause className="text-white text-xl" />
            ) : (
              <Play className="text-white text-xl ml-1" />
            )}
          </Button>
        </div>
        
        {/* Progress Bar */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <div className="bg-white/20 rounded-full h-1">
            <div 
              className="bg-white h-1 rounded-full transition-all"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          <div className="flex justify-between text-white text-xs mt-1">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>
        
        {/* PiP Button */}
        <Button
          size="sm"
          className="absolute top-4 right-4 w-8 h-8 bg-black/50 rounded-full flex items-center justify-center hover:bg-black/70"
        >
          <ExternalLink className="text-white text-xs" />
        </Button>
      </div>
    </div>
  );
}
