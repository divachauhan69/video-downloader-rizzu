import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const downloads = pgTable("downloads", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  thumbnail: text("thumbnail"),
  duration: text("duration"),
  size: text("size"),
  format: text("format").notNull(), // MP4, MP3
  quality: text("quality").notNull(), // 720p, 1080p, 4K, etc.
  platform: text("platform").notNull(), // YouTube, TikTok, Instagram, etc.
  status: text("status").notNull().default("pending"), // pending, downloading, completed, failed
  progress: integer("progress").default(0), // 0-100
  filePath: text("file_path"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const videoInfo = pgTable("video_info", {
  id: serial("id").primaryKey(),
  url: text("url").notNull().unique(),
  title: text("title").notNull(),
  thumbnail: text("thumbnail"),
  duration: text("duration"),
  platform: text("platform").notNull(),
  availableFormats: text("available_formats").array(), // JSON array of format options
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDownloadSchema = createInsertSchema(downloads).omit({
  id: true,
  createdAt: true,
});

export const insertVideoInfoSchema = createInsertSchema(videoInfo).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertDownload = z.infer<typeof insertDownloadSchema>;
export type Download = typeof downloads.$inferSelect;

export type InsertVideoInfo = z.infer<typeof insertVideoInfoSchema>;
export type VideoInfo = typeof videoInfo.$inferSelect;
