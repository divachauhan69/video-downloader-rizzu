import { users, downloads, videoInfo, type User, type InsertUser, type Download, type InsertDownload, type VideoInfo, type InsertVideoInfo } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Download methods
  getDownloads(): Promise<Download[]>;
  getDownload(id: number): Promise<Download | undefined>;
  createDownload(download: InsertDownload): Promise<Download>;
  updateDownload(id: number, updates: Partial<Download>): Promise<Download | undefined>;
  deleteDownload(id: number): Promise<boolean>;
  
  // Video info methods
  getVideoInfo(url: string): Promise<VideoInfo | undefined>;
  createVideoInfo(videoInfo: InsertVideoInfo): Promise<VideoInfo>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private downloads: Map<number, Download>;
  private videoInfos: Map<string, VideoInfo>;
  private currentUserId: number;
  private currentDownloadId: number;
  private currentVideoInfoId: number;

  constructor() {
    this.users = new Map();
    this.downloads = new Map();
    this.videoInfos = new Map();
    this.currentUserId = 1;
    this.currentDownloadId = 1;
    this.currentVideoInfoId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getDownloads(): Promise<Download[]> {
    return Array.from(this.downloads.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async getDownload(id: number): Promise<Download | undefined> {
    return this.downloads.get(id);
  }

  async createDownload(insertDownload: InsertDownload): Promise<Download> {
    const id = this.currentDownloadId++;
    const download: Download = { 
      ...insertDownload, 
      id, 
      createdAt: new Date(),
      progress: insertDownload.progress ?? 0,
      status: insertDownload.status ?? "pending",
      thumbnail: insertDownload.thumbnail ?? null,
      duration: insertDownload.duration ?? null,
      size: insertDownload.size ?? null,
      filePath: insertDownload.filePath ?? null
    };
    this.downloads.set(id, download);
    return download;
  }

  async updateDownload(id: number, updates: Partial<Download>): Promise<Download | undefined> {
    const download = this.downloads.get(id);
    if (!download) return undefined;
    
    const updatedDownload = { ...download, ...updates };
    this.downloads.set(id, updatedDownload);
    return updatedDownload;
  }

  async deleteDownload(id: number): Promise<boolean> {
    return this.downloads.delete(id);
  }

  async getVideoInfo(url: string): Promise<VideoInfo | undefined> {
    return this.videoInfos.get(url);
  }

  async createVideoInfo(insertVideoInfo: InsertVideoInfo): Promise<VideoInfo> {
    const id = this.currentVideoInfoId++;
    const videoInfo: VideoInfo = { 
      ...insertVideoInfo, 
      id, 
      createdAt: new Date(),
      duration: insertVideoInfo.duration ?? null,
      thumbnail: insertVideoInfo.thumbnail ?? null,
      availableFormats: insertVideoInfo.availableFormats ?? null
    };
    this.videoInfos.set(insertVideoInfo.url, videoInfo);
    return videoInfo;
  }
}

export const storage = new MemStorage();
