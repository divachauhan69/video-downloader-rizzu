import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDownloadSchema, insertVideoInfoSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all downloads
  app.get("/api/downloads", async (req, res) => {
    try {
      const downloads = await storage.getDownloads();
      res.json(downloads);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch downloads" });
    }
  });

  // Get video info from URL
  app.post("/api/video-info", async (req, res) => {
    try {
      const { url } = req.body;
      
      if (!url) {
        return res.status(400).json({ message: "URL is required" });
      }

      // Check if we already have info for this URL
      const existingInfo = await storage.getVideoInfo(url);
      if (existingInfo) {
        return res.json(existingInfo);
      }

      // Enhanced mock video info extraction (in real app, use youtube-dl-exec)
      const platformFromUrl = (url: string) => {
        if (url.includes('youtube.com') || url.includes('youtu.be')) return 'YouTube';
        if (url.includes('instagram.com')) return 'Instagram';
        if (url.includes('tiktok.com')) return 'TikTok';
        if (url.includes('facebook.com')) return 'Facebook';
        if (url.includes('twitter.com') || url.includes('x.com')) return 'Twitter';
        return 'Unknown';
      };

      const generateMockData = (platform: string) => {
        // Extract actual video ID and generate realistic titles
        const extractVideoInfo = (url: string, platform: string) => {
          let videoId = '';
          
          if (platform === 'YouTube') {
            const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/);
            videoId = match ? match[1] : 'sample';
          } else if (platform === 'Instagram') {
            const match = url.match(/instagram\.com\/(?:p|reel)\/([^\/\?]+)/);
            videoId = match ? match[1] : 'sample';
          } else if (platform === 'TikTok') {
            const match = url.match(/tiktok\.com\/@[^\/]+\/video\/(\d+)/);
            videoId = match ? match[1] : 'sample';
          }

          return { videoId: videoId.substring(0, 8) };
        };

        const videoTitles = {
          YouTube: [
            "Amazing Nature Documentary - Wildlife in 4K",
            "Complete Web Development Tutorial 2024",
            "Relaxing Piano Music for Study & Work",
            "Epic Travel Vlog - Hidden Gems Around the World",
            "Cooking Masterclass: Professional Techniques"
          ],
          Instagram: [
            "Behind the Scenes: Fashion Photography",
            "Morning Workout Routine That Changed My Life",
            "Easy 5-Minute Healthy Breakfast Recipe",
            "Travel Photography Tips & Tricks",
            "Street Style Fashion Lookbook"
          ],
          TikTok: [
            "This Dance Trend is Taking Over!",
            "Life Hack That Will Save You Hours",
            "When Your Pet Does This...",
            "60-Second Photography Tutorial",
            "Comedy Gold: Daily Life Situations"
          ],
          Facebook: [
            "Family Reunion Highlights 2024",
            "Live: Community Event Coverage",
            "Important Business Update",
            "Educational Content: Did You Know?",
            "Local News and Updates"
          ],
          Twitter: [
            "Breaking: Latest News Update",
            "Thread Explanation: Complex Topic Made Simple",
            "Live Commentary: Current Events",
            "Quick Industry Update",
            "Behind the Scenes: How It's Made"
          ]
        };

        const thumbnails = [
          "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=225",
          "https://images.unsplash.com/photo-1439066615861-d1af74d74000?w=400&h=225",
          "https://images.unsplash.com/photo-1464822759844-d150baec013c?w=400&h=225",
          "https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=225",
          "https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=400&h=225"
        ];

        const durations = ["1:23", "3:45", "5:12", "8:30", "12:15", "15:42"];
        
        const { videoId } = extractVideoInfo(url, platform);
        const titles = videoTitles[platform as keyof typeof videoTitles] || videoTitles.YouTube;
        
        // Use video ID to consistently generate the same data for the same URL
        const titleIndex = videoId.charCodeAt(0) % titles.length;
        const thumbnailIndex = videoId.charCodeAt(1) % thumbnails.length;
        const durationIndex = videoId.charCodeAt(2) % durations.length;
        
        return { 
          title: titles[titleIndex],
          thumbnail: thumbnails[thumbnailIndex],
          duration: durations[durationIndex],
          videoId
        };
      };

      const platform = platformFromUrl(url);
      const mockData = generateMockData(platform);

      const videoInfo = {
        url,
        title: mockData.title,
        thumbnail: mockData.thumbnail,
        duration: mockData.duration,
        platform,
        availableFormats: platform === 'TikTok' ? [
          "1080p Full HD (MP4, 245 MB)",
          "720p HD (MP4, 125 MB)", 
          "480p (MP4, 80 MB)",
          "Audio Only (MP3, 5.2 MB)"
        ] : platform === 'Instagram' ? [
          "1080p Full HD (MP4, 185 MB)",
          "720p HD (MP4, 95 MB)", 
          "480p (MP4, 60 MB)",
          "Audio Only (MP3, 4.8 MB)"
        ] : [
          "4K Ultra HD (MP4, 2.1 GB)",
          "1080p Full HD (MP4, 845 MB)", 
          "720p HD (MP4, 425 MB)",
          "480p (MP4, 280 MB)",
          "Audio Only (MP3, 12.5 MB)"
        ]
      };

      const created = await storage.createVideoInfo(videoInfo);
      res.json(created);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch video info" });
    }
  });

  // Create new download
  app.post("/api/downloads", async (req, res) => {
    try {
      const validatedData = insertDownloadSchema.parse(req.body);
      const download = await storage.createDownload(validatedData);
      
      // Start download process (mock)
      setTimeout(async () => {
        await storage.updateDownload(download.id, { 
          status: "downloading",
          progress: 25 
        });
      }, 1000);

      setTimeout(async () => {
        await storage.updateDownload(download.id, { 
          progress: 75 
        });
      }, 3000);

      setTimeout(async () => {
        await storage.updateDownload(download.id, { 
          status: "completed",
          progress: 100,
          filePath: `/downloads/${download.title}.${download.format.toLowerCase()}`
        });
      }, 5000);

      res.json(download);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid download data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create download" });
    }
  });

  // Update download (for progress, status, etc.)
  app.patch("/api/downloads/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const download = await storage.updateDownload(id, updates);
      if (!download) {
        return res.status(404).json({ message: "Download not found" });
      }
      
      res.json(download);
    } catch (error) {
      res.status(500).json({ message: "Failed to update download" });
    }
  });

  // Delete download
  app.delete("/api/downloads/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteDownload(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Download not found" });
      }
      
      res.json({ message: "Download deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete download" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
